<?php
	session_start();	
	if(isset($_SESSION['rollno'])) {
		header('Location: quiz.php');
	}
?>
<!DOCTYPE html>
<html lang="en">
<title>Online Quiz | Login</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/w3css.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<style>
body {font-family: "Lato", sans-serif}
</style>
<body>

<!-- Navbar -->
<div class="w3-top">
  <div class="w3-bar w3-black w3-card">
    <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a href="index.php" class="w3-bar-item w3-button w3-padding-large">HOME</a>
    <a href="registration.php" class="w3-padding-large w3-hover-orange w3-hide-small w3-right">Sign Up</a>
    
  </div>
</div>


<!-- Page content -->
<div class="w3-content" style="max-width:2000px;">

  <div class="w3-container w3-content w3-center w3-padding-64" style="max-width:600px" id="band">
    <h2 class="w3-wide">Quiz Platform for Students</h2>
    <div class="w3-container w3-margin-top">

    	<div class="w3-center">
	    	<?php
				if (isset($_GET['error'])) {
					echo "<h4 style='color:green;'>".$_GET['error']."</h4>";
				} 
			?>
			<?php
				if (isset($_GET['loginerror'])) {
					echo "<h4 style='color:red;'>".$_GET['loginerror']."</h4>";
				} 
			?>
		</div>
		<form method="POST" action="login.php" class="w3-container w3-card">

			<p>
				<label class="w3-left">Enrollment</label>
				<input class="w3-input" name="rollno" type="text" style="width:100%" required>
			</p>
			<p>
				<label class="w3-left">Password</label>
				<input class="w3-input" name="password" type="password" style="width:100%" required>
			</p>
			<p>

				<button type="submit" value="submit" name="submit" class="w3-button w3-section w3-round-xxlarge w3-black w3-ripple" style="width: 30%; outline: none;"> Log in </button>
			</p>
			<p>
				<a href="registration.php">Don't have Account?</a>
			</p>
		</form>

	</div>
  </div>
  
<!-- End Page Content -->
</div>

<script>

// Used to toggle the menu on small screens when clicking on the menu button
function myFunction() {
  var x = document.getElementById("navDemo");
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else { 
    x.className = x.className.replace(" w3-show", "");
  }
}

</script>

</body>
</html>

<?php
if(isset($_POST['submit'])){

	include('database/dbcon.php');

	$rollno = $_POST['rollno'];
	$password = $_POST['password'];

	$sql = "SELECT rollno,role,password FROM `registration` WHERE rollno = '$rollno' and password = '$password'";

	$run = mysqli_query($con,$sql);
	$data = mysqli_fetch_assoc($run);

	 $role = $data['role'];
	 $rollnumber = $data['rollno'];


	if($role == "admin"){
		$_SESSION['rollno'] = $rollno;
		header('Location:admin/admindash.php');
	}
	else if($role == "student"){
		$_SESSION['rollno'] = $rollno;
	}
	else{ 
		header('Location:login.php?loginerror=May be username or password is wrong or you are not registered with us.');
	}
}

?>